public class MarketGood {
    // 코드를 입력하세요.
}