public class Main {
    public static void main(String[] args) {
        Theater t = new Theater(5, 9);
        t.printSeatMatrix();
    }
}