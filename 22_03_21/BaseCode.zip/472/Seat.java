public class Seat {
    // 여기에 코드를 작성하세요.
}