public class Seat {
    // 여기에 코드를 작성하세요.
    private String name;
    public String getName() {
        return name;
    }

    public void reserve(String name) {
        this.name = name;
    }

    public void cancel() {
        name = null;
    }

    public boolean isOccupied() {
        return name != null;
    }

    public boolean match(String checkName) {
        return name.equals(checkName);
    }
}
/*1. 예약정보(이름, 열, 행, 예약 좌석 수)를 파라미터로 받아 예약하는 메소드
public bollean reserve(Sring name, char rowChar, int col, int numSeat )
        - 존재하지 않는 행 또는 열을 입력하면 false를 리턴하고 메소드를 종료합니다.
        - 만약 1열부터 9열까지밖에 없는데, D7부터 네좌석을 예약하면 false를 리턴하고
        메소드를 종료합니다. 아무 좌석도 예약되면 안됨.
        - D3부터 좌석4개(D3, D4, D5, D6)을 예약 하려고 하는데 D6 이미 예약된 자리라면
        나머지 좌석들(D3, D4, D5)도 예약되면 안됩니다.
        - 문제가 없는 경우, 실제로 예약을 하고 TRUE 리턴합니다.

        2. 이름 name으로 예약된 자리를 취소하고, 취소된 좌석의 수를 리턴합니다.
        예를 들어 "아이유"이름으로 예약된 좌석이 여덟 자리이면 t.cancel("아이유")는
        8을 리턴하는 것이죠. 만약 자리가 없다면 0을 리턴합니다.
public int cancel(Sring name)

public int cancel(char rowChar, int col, int numSeat)
        3. 메소드 오버로딩으로 구현한 또 다른 cancel 메소드 입니다. 이번에는 파라미터로
        '열', '행', '좌석 수'에 해당되는 모든 좌석의 예약을 취소합니다. 그리고 앞의 cancel
        메소드와 마찬가지로 총 취소된 좌석 수를 리턴합니다.
        만약 G2부터 G4까지 세 자리가 예약된 상황에서 t.cancel("g", 3, 4)는 G3 부터 G6까지
        네 자리중, 예약된 G3, G4를 취소하고 2를 리턴해야 합니다. 그런데 만약
        t.cancel('G', 3, 10000) 이런 식으로 열의 범위를 초과하는 좌석이 지정된다면 해당
        행의 가장 오른쪽 끝 열까지 존재하는 모든 좌석의 내약 내역을 취소하면 됩니다.

        4. 예약된 모든 좌석 수를 리턴하는 메소드
public int getNumberOfReservedSeat()

        5. 영화관 행을 해당하는 정수로 변환하는 메소드 예를 들면
        'A'는 0, 'D'는 3으로 변환해 줍니다.

        main*/

/*예약할 좌석을 하나씩 본다 {
    현재 보고 있는 좌석이 이미 예약되어 있다면 {
        앞서 예약한 좌석 모두 취소한다..
        false를 리턴하고 메소드 끝낸다.
        }
        보고 있는 좌석이 빈 좌석이면 예약한다.
        }
        ture를 리턴하고 메소드를 종료한다.*/


/*
출력값

 아이유님 이름으로 A5부터 2개의 좌석 예약: 성공
 제니님 이름으로 C1부터 3개의 좌석 예약: 성공
 손나은님 이름으로 D4부터 7개의 좌석 예약: 실패
 문채원님 이름으로 C7부터 3개의 좌석 예약: 성공
 A6부터 좌석 3개 취소: 총 1개의 좌석이 취소되었습니다.
 제니님의 좌석 취소: 총 3개의 좌석이 취소되었습니다.

     1  2  3  4  5  6  7  8  9
 A: [ ][ ][ ][ ][O][ ][ ][ ][ ]
 B: [ ][ ][ ][ ][ ][ ][ ][ ][ ]
 C: [ ][ ][ ][ ][ ][ ][O][O][O]
 D: [ ][ ][ ][ ][ ][ ][ ][ ][ ]
 E: [ ][ ][ ][ ][ ][ ][ ][ ][ ]
 총 4개의 좌석이 예약되었습니다.*/
