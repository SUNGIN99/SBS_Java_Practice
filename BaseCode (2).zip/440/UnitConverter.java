public class UnitConverter {
    // 필요한 상수 정의

    public static double toPounds(double kilograms) {
        // 메소드 내부를 채워주세요
    }
    public static double toKilograms(double pounds) {
        // 메소드 내부를 채워주세요
    }
    public static double toCentimeters(double inches) {
        // 메소드 내부를 채워주세요
    }
    public static double toInches(double centimeters) {
        // 메소드 내부를 채워주세요
    }
    public static double toFahrenheit(double celsius) {
        // 메소드 내부를 채워주세요
    }
    public static double toCelsius(double fahrenheit) {
        // 메소드 내부를 채워주세요
    }
}